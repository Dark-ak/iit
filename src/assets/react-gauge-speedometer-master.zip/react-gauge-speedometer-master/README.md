# React gauge speedometer

## Build

    npm install || npm i
    npm run build


## Development (first do Build)

    npm run dev

![react gauges-3](https://cloud.githubusercontent.com/assets/2760408/9699128/e4bdaef4-53de-11e5-8d0d-881369726c25.jpg)
